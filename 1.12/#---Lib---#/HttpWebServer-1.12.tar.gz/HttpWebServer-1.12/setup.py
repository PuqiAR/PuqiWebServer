import setuptools

setuptools.setup(
    name="HttpWebServer",
    version="1.12",
    author="PuqiAR",
    author_email="PuqiAR@qq.com",
    description="",
    long_description="HttpWebServer",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)